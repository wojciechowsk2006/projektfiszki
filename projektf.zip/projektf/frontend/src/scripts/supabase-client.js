// ========================================
// KONFIGURACJA SUPABASE
// ========================================
// WAŻNE: Zmień na swoje dane!

const SUPABASE_URL = 'https://kbvjirviaghzauihgdey.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtidmppcnZpYWdoemF1aWhnZGV5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0MTEwODAsImV4cCI6MjA3Njk4NzA4MH0.-EBn4ylz7NAiMprqrg5h5f7lwJFG9jlLnlzLVZlV8zU';

// Inicjalizacja klienta Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// Export dla innych modułów
window.supabaseClient = supabase;
window.SUPABASE_URL = SUPABASE_URL;
window.SUPABASE_ANON_KEY = SUPABASE_ANON_KEY;