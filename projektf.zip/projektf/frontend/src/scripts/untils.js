// Funkcje pomocnicze

const Utils = {
  // Wyświetlanie alertów
  showAlert(message, type = 'error') {
    const alertDiv = document.getElementById('alert-container');
    if (!alertDiv) return;

    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.display = 'block';

    // Auto-ukrywanie po 5 sekundach
    setTimeout(() => {
      alertDiv.style.display = 'none';
    }, 5000);
  },

  // Ukrywanie alertu
  hideAlert() {
    const alertDiv = document.getElementById('alert-container');
    if (alertDiv) {
      alertDiv.style.display = 'none';
    }
  },

  // Walidacja email
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  },

  // Pokazywanie/ukrywanie loadera
  showLoader(buttonElement) {
    if (!buttonElement) return;
    
    const spinner = document.createElement('span');
    spinner.className = 'spinner';
    spinner.id = 'button-spinner';
    buttonElement.appendChild(spinner);
    buttonElement.disabled = true;
  },

  hideLoader(buttonElement) {
    if (!buttonElement) return;
    
    const spinner = document.getElementById('button-spinner');
    if (spinner) {
      spinner.remove();
    }
    buttonElement.disabled = false;
  },

  // Przekierowanie
  redirect(url) {
    window.location.href = url;
  },

  // Local storage helpers
  setItem(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Błąd zapisu do localStorage:', error);
    }
  },

  getItem(key) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Błąd odczytu z localStorage:', error);
      return null;
    }
  },

  removeItem(key) {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Błąd usuwania z localStorage:', error);
    }
  }
};

// Export dla globalnego dostępu
window.Utils = Utils;