// ========================================
// KONFIGURACJA DZIAŁÓW - DODAJ TUTAJ NOWE!
// ========================================

// Lista kategorii fiszek
// Aby dodać nowy dział:
// 1. Dodaj obiekt do tej tablicy
// 2. Dodaj słówka do Supabase (SQL)
// 3. Gotowe! Dział pojawi się automatycznie w Fiszkach i Statystykach

const CATEGORIES = [
  { 
    id: 'owoce',           // ID w bazie danych (category field)
    name: 'Owoce',         // Nazwa wyświetlana
    icon: '🍎'             // Ikona emoji
  },
  { 
    id: 'czasowniki', 
    name: 'Czasowniki', 
    icon: '⚡' 
  },
  { 
    id: 'zdrowie', 
    name: 'Zdrowie', 
    icon: '🏥' 
  },
  
  // ===== DODAJ NOWE DZIAŁY TUTAJ =====
  // Przykład:
  // { 
  //   id: 'zwierzeta',      // Musi być unikalne
  //   name: 'Zwierzęta',    // Może mieć polskie znaki
  //   icon: '🐶'            // Dowolne emoji
  // },
];

// Export dla globalnego dostępu
window.CATEGORIES = CATEGORIES;