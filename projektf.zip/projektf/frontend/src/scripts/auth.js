// Moduł obsługi autentykacji

const Auth = {
  // Logowanie użytkownika
  async login(email, password) {
    try {
      const { data, error } = await window.supabaseClient.auth.signInWithPassword({
        email: email,
        password: password,
      });

      if (error) throw error;
      
      return { success: true, data };
    } catch (error) {
      console.error('Błąd logowania:', error);
      return { 
        success: false, 
        error: error.message || 'Wystąpił błąd podczas logowania' 
      };
    }
  },

  // Wylogowanie użytkownika
  async logout() {
    try {
      const { error } = await window.supabaseClient.auth.signOut();
      if (error) throw error;
      
      window.location.href = '/frontend/src/pages/login.html';
      return { success: true };
    } catch (error) {
      console.error('Błąd wylogowania:', error);
      return { success: false, error: error.message };
    }
  },

  // Sprawdzenie czy użytkownik jest zalogowany
  async getCurrentUser() {
    try {
      const { data: { user }, error } = await window.supabaseClient.auth.getUser();
      
      if (error) throw error;
      
      return { success: true, user };
    } catch (error) {
      console.error('Błąd pobierania użytkownika:', error);
      return { success: false, user: null };
    }
  },

  // Sprawdzenie sesji
  async getSession() {
    try {
      const { data: { session }, error } = await window.supabaseClient.auth.getSession();
      
      if (error) throw error;
      
      return { success: true, session };
    } catch (error) {
      console.error('Błąd pobierania sesji:', error);
      return { success: false, session: null };
    }
  },

  // Nasłuchiwanie zmian stanu autentykacji
  onAuthStateChange(callback) {
    return window.supabaseClient.auth.onAuthStateChange((event, session) => {
      callback(event, session);
    });
  }
};

// Export dla globalnego dostępu
window.Auth = Auth;